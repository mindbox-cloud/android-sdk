package cloud.mindbox.common

internal object BuildConfig {
    internal const val VERSION_NAME = "2.15.5-mobile389-local"
}
