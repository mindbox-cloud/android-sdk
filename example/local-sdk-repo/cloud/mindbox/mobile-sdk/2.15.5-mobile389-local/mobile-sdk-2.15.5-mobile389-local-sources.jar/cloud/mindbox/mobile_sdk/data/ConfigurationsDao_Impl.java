package cloud.mindbox.mobile_sdk.data;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import cloud.mindbox.mobile_sdk.models.Configuration;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.flow.Flow;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class ConfigurationsDao_Impl implements ConfigurationsDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Configuration> __insertionAdapterOfConfiguration;

  public ConfigurationsDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfConfiguration = new EntityInsertionAdapter<Configuration>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `mindbox_configuration_table` (`configurationId`,`previousInstallationId`,`previousDeviceUUID`,`endpointId`,`domain`,`packageName`,`versionName`,`versionCode`,`subscribeCustomerIfCreated`,`shouldCreateCustomer`,`operationsDomain`,`shouldIncludeVersionCode`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Configuration entity) {
        statement.bindLong(1, entity.getConfigurationId());
        statement.bindString(2, entity.getPreviousInstallationId());
        statement.bindString(3, entity.getPreviousDeviceUUID());
        statement.bindString(4, entity.getEndpointId());
        statement.bindString(5, entity.getDomain());
        statement.bindString(6, entity.getPackageName());
        statement.bindString(7, entity.getVersionName());
        statement.bindString(8, entity.getVersionCode());
        final int _tmp = entity.getSubscribeCustomerIfCreated() ? 1 : 0;
        statement.bindLong(9, _tmp);
        final int _tmp_1 = entity.getShouldCreateCustomer() ? 1 : 0;
        statement.bindLong(10, _tmp_1);
        if (entity.getOperationsDomain() == null) {
          statement.bindNull(11);
        } else {
          statement.bindString(11, entity.getOperationsDomain());
        }
        final int _tmp_2 = entity.getShouldIncludeVersionCode() ? 1 : 0;
        statement.bindLong(12, _tmp_2);
      }
    };
  }

  @Override
  public void insert(final Configuration configuration) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfConfiguration.insert(configuration);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public Configuration get() {
    final String _sql = "SELECT * FROM mindbox_configuration_table ORDER BY configurationId DESC LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfConfigurationId = CursorUtil.getColumnIndexOrThrow(_cursor, "configurationId");
      final int _cursorIndexOfPreviousInstallationId = CursorUtil.getColumnIndexOrThrow(_cursor, "previousInstallationId");
      final int _cursorIndexOfPreviousDeviceUUID = CursorUtil.getColumnIndexOrThrow(_cursor, "previousDeviceUUID");
      final int _cursorIndexOfEndpointId = CursorUtil.getColumnIndexOrThrow(_cursor, "endpointId");
      final int _cursorIndexOfDomain = CursorUtil.getColumnIndexOrThrow(_cursor, "domain");
      final int _cursorIndexOfPackageName = CursorUtil.getColumnIndexOrThrow(_cursor, "packageName");
      final int _cursorIndexOfVersionName = CursorUtil.getColumnIndexOrThrow(_cursor, "versionName");
      final int _cursorIndexOfVersionCode = CursorUtil.getColumnIndexOrThrow(_cursor, "versionCode");
      final int _cursorIndexOfSubscribeCustomerIfCreated = CursorUtil.getColumnIndexOrThrow(_cursor, "subscribeCustomerIfCreated");
      final int _cursorIndexOfShouldCreateCustomer = CursorUtil.getColumnIndexOrThrow(_cursor, "shouldCreateCustomer");
      final int _cursorIndexOfOperationsDomain = CursorUtil.getColumnIndexOrThrow(_cursor, "operationsDomain");
      final int _cursorIndexOfShouldIncludeVersionCode = CursorUtil.getColumnIndexOrThrow(_cursor, "shouldIncludeVersionCode");
      final Configuration _result;
      if (_cursor.moveToFirst()) {
        final long _tmpConfigurationId;
        _tmpConfigurationId = _cursor.getLong(_cursorIndexOfConfigurationId);
        final String _tmpPreviousInstallationId;
        _tmpPreviousInstallationId = _cursor.getString(_cursorIndexOfPreviousInstallationId);
        final String _tmpPreviousDeviceUUID;
        _tmpPreviousDeviceUUID = _cursor.getString(_cursorIndexOfPreviousDeviceUUID);
        final String _tmpEndpointId;
        _tmpEndpointId = _cursor.getString(_cursorIndexOfEndpointId);
        final String _tmpDomain;
        _tmpDomain = _cursor.getString(_cursorIndexOfDomain);
        final String _tmpPackageName;
        _tmpPackageName = _cursor.getString(_cursorIndexOfPackageName);
        final String _tmpVersionName;
        _tmpVersionName = _cursor.getString(_cursorIndexOfVersionName);
        final String _tmpVersionCode;
        _tmpVersionCode = _cursor.getString(_cursorIndexOfVersionCode);
        final boolean _tmpSubscribeCustomerIfCreated;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfSubscribeCustomerIfCreated);
        _tmpSubscribeCustomerIfCreated = _tmp != 0;
        final boolean _tmpShouldCreateCustomer;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfShouldCreateCustomer);
        _tmpShouldCreateCustomer = _tmp_1 != 0;
        final String _tmpOperationsDomain;
        if (_cursor.isNull(_cursorIndexOfOperationsDomain)) {
          _tmpOperationsDomain = null;
        } else {
          _tmpOperationsDomain = _cursor.getString(_cursorIndexOfOperationsDomain);
        }
        final boolean _tmpShouldIncludeVersionCode;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfShouldIncludeVersionCode);
        _tmpShouldIncludeVersionCode = _tmp_2 != 0;
        _result = new Configuration(_tmpConfigurationId,_tmpPreviousInstallationId,_tmpPreviousDeviceUUID,_tmpEndpointId,_tmpDomain,_tmpPackageName,_tmpVersionName,_tmpVersionCode,_tmpSubscribeCustomerIfCreated,_tmpShouldCreateCustomer,_tmpOperationsDomain,_tmpShouldIncludeVersionCode);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Flow<Configuration> listenConfiguration() {
    final String _sql = "SELECT * FROM mindbox_configuration_table ORDER BY configurationId DESC LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"mindbox_configuration_table"}, new Callable<Configuration>() {
      @Override
      @NonNull
      public Configuration call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfConfigurationId = CursorUtil.getColumnIndexOrThrow(_cursor, "configurationId");
          final int _cursorIndexOfPreviousInstallationId = CursorUtil.getColumnIndexOrThrow(_cursor, "previousInstallationId");
          final int _cursorIndexOfPreviousDeviceUUID = CursorUtil.getColumnIndexOrThrow(_cursor, "previousDeviceUUID");
          final int _cursorIndexOfEndpointId = CursorUtil.getColumnIndexOrThrow(_cursor, "endpointId");
          final int _cursorIndexOfDomain = CursorUtil.getColumnIndexOrThrow(_cursor, "domain");
          final int _cursorIndexOfPackageName = CursorUtil.getColumnIndexOrThrow(_cursor, "packageName");
          final int _cursorIndexOfVersionName = CursorUtil.getColumnIndexOrThrow(_cursor, "versionName");
          final int _cursorIndexOfVersionCode = CursorUtil.getColumnIndexOrThrow(_cursor, "versionCode");
          final int _cursorIndexOfSubscribeCustomerIfCreated = CursorUtil.getColumnIndexOrThrow(_cursor, "subscribeCustomerIfCreated");
          final int _cursorIndexOfShouldCreateCustomer = CursorUtil.getColumnIndexOrThrow(_cursor, "shouldCreateCustomer");
          final int _cursorIndexOfOperationsDomain = CursorUtil.getColumnIndexOrThrow(_cursor, "operationsDomain");
          final int _cursorIndexOfShouldIncludeVersionCode = CursorUtil.getColumnIndexOrThrow(_cursor, "shouldIncludeVersionCode");
          final Configuration _result;
          if (_cursor.moveToFirst()) {
            final long _tmpConfigurationId;
            _tmpConfigurationId = _cursor.getLong(_cursorIndexOfConfigurationId);
            final String _tmpPreviousInstallationId;
            _tmpPreviousInstallationId = _cursor.getString(_cursorIndexOfPreviousInstallationId);
            final String _tmpPreviousDeviceUUID;
            _tmpPreviousDeviceUUID = _cursor.getString(_cursorIndexOfPreviousDeviceUUID);
            final String _tmpEndpointId;
            _tmpEndpointId = _cursor.getString(_cursorIndexOfEndpointId);
            final String _tmpDomain;
            _tmpDomain = _cursor.getString(_cursorIndexOfDomain);
            final String _tmpPackageName;
            _tmpPackageName = _cursor.getString(_cursorIndexOfPackageName);
            final String _tmpVersionName;
            _tmpVersionName = _cursor.getString(_cursorIndexOfVersionName);
            final String _tmpVersionCode;
            _tmpVersionCode = _cursor.getString(_cursorIndexOfVersionCode);
            final boolean _tmpSubscribeCustomerIfCreated;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfSubscribeCustomerIfCreated);
            _tmpSubscribeCustomerIfCreated = _tmp != 0;
            final boolean _tmpShouldCreateCustomer;
            final int _tmp_1;
            _tmp_1 = _cursor.getInt(_cursorIndexOfShouldCreateCustomer);
            _tmpShouldCreateCustomer = _tmp_1 != 0;
            final String _tmpOperationsDomain;
            if (_cursor.isNull(_cursorIndexOfOperationsDomain)) {
              _tmpOperationsDomain = null;
            } else {
              _tmpOperationsDomain = _cursor.getString(_cursorIndexOfOperationsDomain);
            }
            final boolean _tmpShouldIncludeVersionCode;
            final int _tmp_2;
            _tmp_2 = _cursor.getInt(_cursorIndexOfShouldIncludeVersionCode);
            _tmpShouldIncludeVersionCode = _tmp_2 != 0;
            _result = new Configuration(_tmpConfigurationId,_tmpPreviousInstallationId,_tmpPreviousDeviceUUID,_tmpEndpointId,_tmpDomain,_tmpPackageName,_tmpVersionName,_tmpVersionCode,_tmpSubscribeCustomerIfCreated,_tmpShouldCreateCustomer,_tmpOperationsDomain,_tmpShouldIncludeVersionCode);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
