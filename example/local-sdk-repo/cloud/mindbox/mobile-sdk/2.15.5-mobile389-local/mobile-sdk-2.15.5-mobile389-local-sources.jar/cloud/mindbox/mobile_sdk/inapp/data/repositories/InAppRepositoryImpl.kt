package cloud.mindbox.mobile_sdk.inapp.data.repositories

import android.content.Context
import cloud.mindbox.mobile_sdk.inapp.data.managers.SessionStorageManager
import cloud.mindbox.mobile_sdk.inapp.domain.interfaces.managers.InAppSerializationManager
import cloud.mindbox.mobile_sdk.inapp.domain.interfaces.repositories.InAppRepository
import cloud.mindbox.mobile_sdk.inapp.domain.models.Frequency
import cloud.mindbox.mobile_sdk.inapp.domain.models.InApp
import cloud.mindbox.mobile_sdk.logger.mindboxLogI
import cloud.mindbox.mobile_sdk.managers.MindboxEventManager
import cloud.mindbox.mobile_sdk.models.InAppEventType
import cloud.mindbox.mobile_sdk.models.Timestamp
import cloud.mindbox.mobile_sdk.models.operation.request.InAppShowFailure
import cloud.mindbox.mobile_sdk.repository.MindboxPreferences
import cloud.mindbox.mobile_sdk.utils.SystemTimeProvider
import kotlinx.coroutines.flow.Flow
import java.util.concurrent.TimeUnit

internal class InAppRepositoryImpl(
    private val context: Context,
    private val sessionStorageManager: SessionStorageManager,
    private val inAppSerializationManager: InAppSerializationManager,
    private val timeProvider: SystemTimeProvider
) : InAppRepository {

    companion object {
        private const val IN_APP_SHOWN_EXPIRATION_DAYS = 2L
    }

    override fun saveCurrentSessionInApps(inApps: List<InApp>) {
        sessionStorageManager.currentSessionInApps = inApps
    }

    override fun getCurrentSessionInApps(): List<InApp> {
        return sessionStorageManager.currentSessionInApps
    }

    override fun getTargetedInApps(): Map<String, MutableSet<Int>> {
        return sessionStorageManager.shownInAppIdsWithEvents
    }

    override fun saveTargetedInAppWithEvent(inAppId: String, eventHashcode: Int) {
        sessionStorageManager.shownInAppIdsWithEvents[inAppId] =
            sessionStorageManager.shownInAppIdsWithEvents.getOrElse(inAppId) {
                mutableSetOf()
            }.apply {
                add(eventHashcode)
            }
    }

    override fun saveUnShownOperationalInApp(operation: String, inApp: InApp) {
        sessionStorageManager.unShownOperationalInApps[operation] =
            sessionStorageManager.unShownOperationalInApps.getOrElse(operation) {
                mutableListOf()
            }.apply {
                add(inApp)
            }
    }

    override fun getUnShownOperationalInAppsByOperation(operation: String): List<InApp> {
        return sessionStorageManager.unShownOperationalInApps[operation.lowercase()] ?: emptyList()
    }

    override fun saveOperationalInApp(operation: String, inApp: InApp) {
        sessionStorageManager.operationalInApps[operation] =
            sessionStorageManager.operationalInApps.getOrElse(operation) {
                mutableListOf()
            }.apply {
                add(inApp)
            }
    }

    override fun getOperationalInAppsByOperation(operation: String): List<InApp> {
        return sessionStorageManager.operationalInApps[operation.lowercase()] ?: emptyList()
    }

    override fun getShownInApps(): Map<String, List<Long>> {
        return inAppSerializationManager.deserializeToShownInAppsMap(MindboxPreferences.shownInApps)
    }

    override fun listenInAppEvents(): Flow<InAppEventType> {
        return MindboxEventManager.eventFlow
    }

    override fun saveShownInApp(id: String, timeStamp: Long) {
        val currentShownInApps = getShownInApps()
        val currentTime = timeProvider.currentTimeMillis()

        val newShownInAppsById = currentShownInApps.getOrElse(id) { emptyList() }
            .filter { currentTime - it <= TimeUnit.DAYS.toMillis(IN_APP_SHOWN_EXPIRATION_DAYS) }
            .plus(timeStamp)
        val shownInApps = currentShownInApps + (id to newShownInAppsById)
        inAppSerializationManager.serializeToShownInAppsString(shownInApps).also {
            if (it.isNotBlank()) {
                MindboxPreferences.shownInApps = it
            }
        }
        mindboxLogI("Increase count of shown inapp per day")
    }

    override fun sendInAppShown(inAppId: String, timeToDisplay: String, tags: Map<String, String>?) {
        inAppSerializationManager.serializeToInAppShownActionString(inAppId, timeToDisplay, tags).apply {
            if (isNotBlank()) {
                MindboxEventManager.inAppShown(
                    context,
                    this
                )
            }
        }
    }

    override fun sendInAppClicked(inAppId: String, tags: Map<String, String>?) {
        inAppSerializationManager.serializeToInAppClickActionString(inAppId, tags).apply {
            if (isNotBlank()) {
                MindboxEventManager.inAppClicked(
                    context,
                    this
                )
            }
        }
    }

    override fun sendUserTargeted(inAppId: String, tags: Map<String, String>?) {
        inAppSerializationManager.serializeToInAppTargetingString(inAppId, tags).apply {
            if (isNotBlank()) {
                MindboxEventManager.sendUserTargeted(
                    context,
                    this
                )
            }
        }
    }

    override fun sendInAppShowFailure(failures: List<InAppShowFailure>) {
        failures
            .takeIf { it.isNotEmpty() }
            ?.let {
                inAppSerializationManager.serializeToInAppShowFailuresString(failures)
                    .takeIf { it.isNotBlank() }
                    ?.let { operationBody ->
                        MindboxEventManager.inAppShowFailure(context, operationBody)
                    }
            }
    }

    override fun isInAppShown(inAppId: String): Boolean {
        return sessionStorageManager.inAppMessageShownInSession.any { it == inAppId }
    }

    override fun clearInAppEvents() {
        MindboxEventManager.resetEventFlowCache()
    }

    override fun isTimeDelayInapp(inAppId: String): Boolean =
        sessionStorageManager.currentSessionInApps
            .any { it.id == inAppId && it.frequency.delay is Frequency.Delay.TimeDelay }

    override fun setInAppShown(inAppId: String) {
        mindboxLogI("Increase count of shown inapp per session, previous count ${sessionStorageManager.inAppMessageShownInSession.size}")
        sessionStorageManager.inAppMessageShownInSession.add(inAppId)
    }

    override fun getLastInappDismissTime(): Timestamp = MindboxPreferences.lastInappChangeStateTime

    override fun saveInAppStateChangeTime(timeStamp: Timestamp) {
        mindboxLogI("Save last inapp state changed with timestamp $timeStamp")
        MindboxPreferences.lastInappChangeStateTime = timeStamp
    }
}
