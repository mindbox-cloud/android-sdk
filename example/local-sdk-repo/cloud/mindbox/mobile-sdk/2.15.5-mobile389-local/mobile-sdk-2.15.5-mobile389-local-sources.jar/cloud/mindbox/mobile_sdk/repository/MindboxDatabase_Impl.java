package cloud.mindbox.mobile_sdk.repository;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import cloud.mindbox.mobile_sdk.data.ConfigurationsDao;
import cloud.mindbox.mobile_sdk.data.ConfigurationsDao_Impl;
import cloud.mindbox.mobile_sdk.data.EventsDao;
import cloud.mindbox.mobile_sdk.data.EventsDao_Impl;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class MindboxDatabase_Impl extends MindboxDatabase {
  private volatile ConfigurationsDao _configurationsDao;

  private volatile EventsDao _eventsDao;

  @Override
  @NonNull
  protected SupportSQLiteOpenHelper createOpenHelper(@NonNull final DatabaseConfiguration config) {
    final SupportSQLiteOpenHelper.Callback _openCallback = new RoomOpenHelper(config, new RoomOpenHelper.Delegate(4) {
      @Override
      public void createAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `mindbox_configuration_table` (`configurationId` INTEGER NOT NULL, `previousInstallationId` TEXT NOT NULL, `previousDeviceUUID` TEXT NOT NULL, `endpointId` TEXT NOT NULL, `domain` TEXT NOT NULL, `packageName` TEXT NOT NULL, `versionName` TEXT NOT NULL, `versionCode` TEXT NOT NULL, `subscribeCustomerIfCreated` INTEGER NOT NULL, `shouldCreateCustomer` INTEGER NOT NULL, `operationsDomain` TEXT, `shouldIncludeVersionCode` INTEGER NOT NULL, PRIMARY KEY(`configurationId`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `mindbox_events_table` (`uid` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `eventType` TEXT NOT NULL, `transactionId` TEXT NOT NULL, `enqueueTimestamp` INTEGER NOT NULL, `additionalFields` TEXT, `body` TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '820b0e84b0c763e84ecba794455b957c')");
      }

      @Override
      public void dropAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS `mindbox_configuration_table`");
        db.execSQL("DROP TABLE IF EXISTS `mindbox_events_table`");
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onDestructiveMigration(db);
          }
        }
      }

      @Override
      public void onCreate(@NonNull final SupportSQLiteDatabase db) {
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onCreate(db);
          }
        }
      }

      @Override
      public void onOpen(@NonNull final SupportSQLiteDatabase db) {
        mDatabase = db;
        internalInitInvalidationTracker(db);
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onOpen(db);
          }
        }
      }

      @Override
      public void onPreMigrate(@NonNull final SupportSQLiteDatabase db) {
        DBUtil.dropFtsSyncTriggers(db);
      }

      @Override
      public void onPostMigrate(@NonNull final SupportSQLiteDatabase db) {
      }

      @Override
      @NonNull
      public RoomOpenHelper.ValidationResult onValidateSchema(
          @NonNull final SupportSQLiteDatabase db) {
        final HashMap<String, TableInfo.Column> _columnsMindboxConfigurationTable = new HashMap<String, TableInfo.Column>(12);
        _columnsMindboxConfigurationTable.put("configurationId", new TableInfo.Column("configurationId", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("previousInstallationId", new TableInfo.Column("previousInstallationId", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("previousDeviceUUID", new TableInfo.Column("previousDeviceUUID", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("endpointId", new TableInfo.Column("endpointId", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("domain", new TableInfo.Column("domain", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("packageName", new TableInfo.Column("packageName", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("versionName", new TableInfo.Column("versionName", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("versionCode", new TableInfo.Column("versionCode", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("subscribeCustomerIfCreated", new TableInfo.Column("subscribeCustomerIfCreated", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("shouldCreateCustomer", new TableInfo.Column("shouldCreateCustomer", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("operationsDomain", new TableInfo.Column("operationsDomain", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxConfigurationTable.put("shouldIncludeVersionCode", new TableInfo.Column("shouldIncludeVersionCode", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysMindboxConfigurationTable = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesMindboxConfigurationTable = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoMindboxConfigurationTable = new TableInfo("mindbox_configuration_table", _columnsMindboxConfigurationTable, _foreignKeysMindboxConfigurationTable, _indicesMindboxConfigurationTable);
        final TableInfo _existingMindboxConfigurationTable = TableInfo.read(db, "mindbox_configuration_table");
        if (!_infoMindboxConfigurationTable.equals(_existingMindboxConfigurationTable)) {
          return new RoomOpenHelper.ValidationResult(false, "mindbox_configuration_table(cloud.mindbox.mobile_sdk.models.Configuration).\n"
                  + " Expected:\n" + _infoMindboxConfigurationTable + "\n"
                  + " Found:\n" + _existingMindboxConfigurationTable);
        }
        final HashMap<String, TableInfo.Column> _columnsMindboxEventsTable = new HashMap<String, TableInfo.Column>(6);
        _columnsMindboxEventsTable.put("uid", new TableInfo.Column("uid", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxEventsTable.put("eventType", new TableInfo.Column("eventType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxEventsTable.put("transactionId", new TableInfo.Column("transactionId", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxEventsTable.put("enqueueTimestamp", new TableInfo.Column("enqueueTimestamp", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxEventsTable.put("additionalFields", new TableInfo.Column("additionalFields", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMindboxEventsTable.put("body", new TableInfo.Column("body", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysMindboxEventsTable = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesMindboxEventsTable = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoMindboxEventsTable = new TableInfo("mindbox_events_table", _columnsMindboxEventsTable, _foreignKeysMindboxEventsTable, _indicesMindboxEventsTable);
        final TableInfo _existingMindboxEventsTable = TableInfo.read(db, "mindbox_events_table");
        if (!_infoMindboxEventsTable.equals(_existingMindboxEventsTable)) {
          return new RoomOpenHelper.ValidationResult(false, "mindbox_events_table(cloud.mindbox.mobile_sdk.models.Event).\n"
                  + " Expected:\n" + _infoMindboxEventsTable + "\n"
                  + " Found:\n" + _existingMindboxEventsTable);
        }
        return new RoomOpenHelper.ValidationResult(true, null);
      }
    }, "820b0e84b0c763e84ecba794455b957c", "c96b04b6319055b6678e94ebeae1f5c1");
    final SupportSQLiteOpenHelper.Configuration _sqliteConfig = SupportSQLiteOpenHelper.Configuration.builder(config.context).name(config.name).callback(_openCallback).build();
    final SupportSQLiteOpenHelper _helper = config.sqliteOpenHelperFactory.create(_sqliteConfig);
    return _helper;
  }

  @Override
  @NonNull
  protected InvalidationTracker createInvalidationTracker() {
    final HashMap<String, String> _shadowTablesMap = new HashMap<String, String>(0);
    final HashMap<String, Set<String>> _viewTables = new HashMap<String, Set<String>>(0);
    return new InvalidationTracker(this, _shadowTablesMap, _viewTables, "mindbox_configuration_table","mindbox_events_table");
  }

  @Override
  public void clearAllTables() {
    super.assertNotMainThread();
    final SupportSQLiteDatabase _db = super.getOpenHelper().getWritableDatabase();
    try {
      super.beginTransaction();
      _db.execSQL("DELETE FROM `mindbox_configuration_table`");
      _db.execSQL("DELETE FROM `mindbox_events_table`");
      super.setTransactionSuccessful();
    } finally {
      super.endTransaction();
      _db.query("PRAGMA wal_checkpoint(FULL)").close();
      if (!_db.inTransaction()) {
        _db.execSQL("VACUUM");
      }
    }
  }

  @Override
  @NonNull
  protected Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
    final HashMap<Class<?>, List<Class<?>>> _typeConvertersMap = new HashMap<Class<?>, List<Class<?>>>();
    _typeConvertersMap.put(ConfigurationsDao.class, ConfigurationsDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(EventsDao.class, EventsDao_Impl.getRequiredConverters());
    return _typeConvertersMap;
  }

  @Override
  @NonNull
  public Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
    final HashSet<Class<? extends AutoMigrationSpec>> _autoMigrationSpecsSet = new HashSet<Class<? extends AutoMigrationSpec>>();
    return _autoMigrationSpecsSet;
  }

  @Override
  @NonNull
  public List<Migration> getAutoMigrations(
      @NonNull final Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> autoMigrationSpecs) {
    final List<Migration> _autoMigrations = new ArrayList<Migration>();
    return _autoMigrations;
  }

  @Override
  public ConfigurationsDao configurationDao() {
    if (_configurationsDao != null) {
      return _configurationsDao;
    } else {
      synchronized(this) {
        if(_configurationsDao == null) {
          _configurationsDao = new ConfigurationsDao_Impl(this);
        }
        return _configurationsDao;
      }
    }
  }

  @Override
  public EventsDao eventsDao() {
    if (_eventsDao != null) {
      return _eventsDao;
    } else {
      synchronized(this) {
        if(_eventsDao == null) {
          _eventsDao = new EventsDao_Impl(this);
        }
        return _eventsDao;
      }
    }
  }
}
