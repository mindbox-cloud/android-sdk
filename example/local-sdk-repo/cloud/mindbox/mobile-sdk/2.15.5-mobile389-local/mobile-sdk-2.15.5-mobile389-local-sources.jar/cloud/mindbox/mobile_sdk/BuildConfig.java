/**
 * Automatically generated file. DO NOT MODIFY
 */
package cloud.mindbox.mobile_sdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "cloud.mindbox.mobile_sdk";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "2.15.5-mobile389-local";
}
