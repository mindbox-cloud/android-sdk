package cloud.mindbox.mobile_sdk.models

import cloud.mindbox.mobile_sdk.convertToString
import cloud.mindbox.mobile_sdk.convertToZonedDateTimeAtUTC
import org.threeten.bp.Instant

/**
 * Represents a specific point in time as milliseconds since the Unix epoch (January 1, 1970, 00:00:00 UTC)
 */
@JvmInline
internal value class Timestamp(val ms: Long) {
    operator fun plus(milliseconds: Long): Timestamp = Timestamp(ms + milliseconds)

    operator fun minus(timestamp: Timestamp): Timestamp = Timestamp(ms - timestamp.ms)

    companion object {
        val ZERO: Timestamp = Timestamp(0L)
    }
}

internal fun Long.toTimestamp(): Timestamp = Timestamp(this)

internal fun Timestamp.convertToIso8601String(): String {
    return Instant.ofEpochMilli(ms)
        .convertToZonedDateTimeAtUTC()
        .convertToString()
}
