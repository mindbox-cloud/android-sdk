package cloud.mindbox.mobile_sdk.monitoring.data.room.dao;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import cloud.mindbox.mobile_sdk.monitoring.data.room.entities.MonitoringEntity;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class MonitoringDao_Impl implements MonitoringDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<MonitoringEntity> __insertionAdapterOfMonitoringEntity;

  private final EntityDeletionOrUpdateAdapter<MonitoringEntity> __deletionAdapterOfMonitoringEntity;

  private final SharedSQLiteStatement __preparedStmtOfDeleteFirstTenPercentOfLogs;

  private final SharedSQLiteStatement __preparedStmtOfDeleteFirstLog;

  public MonitoringDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfMonitoringEntity = new EntityInsertionAdapter<MonitoringEntity>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `mb_monitoring` (`id`,`timestamp`,`log`) VALUES (nullif(?, 0),?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final MonitoringEntity entity) {
        statement.bindLong(1, entity.getId());
        statement.bindString(2, entity.getTime());
        statement.bindString(3, entity.getLog());
      }
    };
    this.__deletionAdapterOfMonitoringEntity = new EntityDeletionOrUpdateAdapter<MonitoringEntity>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `mb_monitoring` WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final MonitoringEntity entity) {
        statement.bindLong(1, entity.getId());
      }
    };
    this.__preparedStmtOfDeleteFirstTenPercentOfLogs = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM mb_monitoring WHERE id IN (SELECT id FROM mb_monitoring ORDER BY id ASC LIMIT (SELECT CNT/10 FROM (SELECT COUNT(id) as CNT FROM mb_monitoring)))";
        return _query;
      }
    };
    this.__preparedStmtOfDeleteFirstLog = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM mb_monitoring WHERE id IN (SELECT id FROM mb_monitoring ORDER BY id ASC LIMIT 1)";
        return _query;
      }
    };
  }

  @Override
  public Object insertLog(final MonitoringEntity entity,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __insertionAdapterOfMonitoringEntity.insert(entity);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object deleteLog(final MonitoringEntity log,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __deletionAdapterOfMonitoringEntity.handle(log);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object deleteFirstTenPercentOfLogs(final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteFirstTenPercentOfLogs.acquire();
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfDeleteFirstTenPercentOfLogs.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Object deleteFirstLog(final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteFirstLog.acquire();
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfDeleteFirstLog.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Object getLogs(final String startTime, final String endTime,
      final Continuation<? super List<MonitoringEntity>> $completion) {
    final String _sql = "SELECT * FROM mb_monitoring WHERE timestamp BETWEEN ? and ? ORDER BY timestamp ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindString(_argIndex, startTime);
    _argIndex = 2;
    _statement.bindString(_argIndex, endTime);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<List<MonitoringEntity>>() {
      @Override
      @NonNull
      public List<MonitoringEntity> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfTime = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
          final int _cursorIndexOfLog = CursorUtil.getColumnIndexOrThrow(_cursor, "log");
          final List<MonitoringEntity> _result = new ArrayList<MonitoringEntity>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final MonitoringEntity _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpTime;
            _tmpTime = _cursor.getString(_cursorIndexOfTime);
            final String _tmpLog;
            _tmpLog = _cursor.getString(_cursorIndexOfLog);
            _item = new MonitoringEntity(_tmpId,_tmpTime,_tmpLog);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object getFirstLog(final Continuation<? super MonitoringEntity> $completion) {
    final String _sql = "SELECT * FROM mb_monitoring ORDER BY id ASC LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<MonitoringEntity>() {
      @Override
      @NonNull
      public MonitoringEntity call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfTime = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
          final int _cursorIndexOfLog = CursorUtil.getColumnIndexOrThrow(_cursor, "log");
          final MonitoringEntity _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpTime;
            _tmpTime = _cursor.getString(_cursorIndexOfTime);
            final String _tmpLog;
            _tmpLog = _cursor.getString(_cursorIndexOfLog);
            _result = new MonitoringEntity(_tmpId,_tmpTime,_tmpLog);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object getLastLog(final Continuation<? super MonitoringEntity> $completion) {
    final String _sql = "SELECT * FROM mb_monitoring ORDER BY id DESC LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<MonitoringEntity>() {
      @Override
      @NonNull
      public MonitoringEntity call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfTime = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
          final int _cursorIndexOfLog = CursorUtil.getColumnIndexOrThrow(_cursor, "log");
          final MonitoringEntity _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpTime;
            _tmpTime = _cursor.getString(_cursorIndexOfTime);
            final String _tmpLog;
            _tmpLog = _cursor.getString(_cursorIndexOfLog);
            _result = new MonitoringEntity(_tmpId,_tmpTime,_tmpLog);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
