package cloud.mindbox.mobile_sdk.inapp.domain.interfaces.repositories

import cloud.mindbox.mobile_sdk.inapp.domain.models.InApp
import cloud.mindbox.mobile_sdk.models.InAppEventType
import cloud.mindbox.mobile_sdk.models.Timestamp
import cloud.mindbox.mobile_sdk.models.operation.request.InAppShowFailure
import kotlinx.coroutines.flow.Flow

internal interface InAppRepository {
    fun saveCurrentSessionInApps(inApps: List<InApp>)

    fun getShownInApps(): Map<String, List<Long>>

    fun getCurrentSessionInApps(): List<InApp>

    fun getTargetedInApps(): Map<String, MutableSet<Int>>

    fun saveTargetedInAppWithEvent(inAppId: String, eventHashcode: Int)

    fun saveUnShownOperationalInApp(operation: String, inApp: InApp)

    fun getUnShownOperationalInAppsByOperation(operation: String): List<InApp>

    fun saveOperationalInApp(operation: String, inApp: InApp)

    fun getOperationalInAppsByOperation(operation: String): List<InApp>

    fun listenInAppEvents(): Flow<InAppEventType>

    fun saveShownInApp(id: String, timeStamp: Long)

    fun sendInAppShown(inAppId: String, timeToDisplay: String, tags: Map<String, String>?)

    fun sendInAppClicked(inAppId: String, tags: Map<String, String>?)

    fun sendUserTargeted(inAppId: String, tags: Map<String, String>?)

    fun sendInAppShowFailure(failures: List<InAppShowFailure>)

    fun setInAppShown(inAppId: String)

    fun isInAppShown(inAppId: String): Boolean

    fun clearInAppEvents()

    fun isTimeDelayInapp(inAppId: String): Boolean

    fun getLastInappDismissTime(): Timestamp

    fun saveInAppStateChangeTime(timeStamp: Timestamp)
}
