package cloud.mindbox.mobile_sdk.data;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import cloud.mindbox.mobile_sdk.converters.MindboxRoomConverter;
import cloud.mindbox.mobile_sdk.models.Event;
import cloud.mindbox.mobile_sdk.models.EventType;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class EventsDao_Impl implements EventsDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Event> __insertionAdapterOfEvent;

  private final EntityDeletionOrUpdateAdapter<Event> __deletionAdapterOfEvent;

  private final SharedSQLiteStatement __preparedStmtOfDelete;

  private final SharedSQLiteStatement __preparedStmtOfDeleteAll;

  public EventsDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfEvent = new EntityInsertionAdapter<Event>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR ABORT INTO `mindbox_events_table` (`uid`,`eventType`,`transactionId`,`enqueueTimestamp`,`additionalFields`,`body`) VALUES (nullif(?, 0),?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Event entity) {
        statement.bindLong(1, entity.getUid());
        final String _tmp = MindboxRoomConverter.INSTANCE.eventTypeToString(entity.getEventType());
        statement.bindString(2, _tmp);
        statement.bindString(3, entity.getTransactionId());
        statement.bindLong(4, entity.getEnqueueTimestamp());
        final String _tmp_1 = MindboxRoomConverter.INSTANCE.hashMapToString(entity.getAdditionalFields());
        if (_tmp_1 == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, _tmp_1);
        }
        if (entity.getBody() == null) {
          statement.bindNull(6);
        } else {
          statement.bindString(6, entity.getBody());
        }
      }
    };
    this.__deletionAdapterOfEvent = new EntityDeletionOrUpdateAdapter<Event>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `mindbox_events_table` WHERE `uid` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Event entity) {
        statement.bindLong(1, entity.getUid());
      }
    };
    this.__preparedStmtOfDelete = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM mindbox_events_table WHERE transactionId = ?";
        return _query;
      }
    };
    this.__preparedStmtOfDeleteAll = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM mindbox_events_table";
        return _query;
      }
    };
  }

  @Override
  public void insert(final Event event) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfEvent.insert(event);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteEvents(final List<Event> events) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfEvent.handleMultiple(events);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final String transactionId) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDelete.acquire();
    int _argIndex = 1;
    _stmt.bindString(_argIndex, transactionId);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDelete.release(_stmt);
    }
  }

  @Override
  public void deleteAll() {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteAll.acquire();
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDeleteAll.release(_stmt);
    }
  }

  @Override
  public List<Event> getAll() {
    final String _sql = "SELECT * FROM mindbox_events_table";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
      try {
        final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
        final int _cursorIndexOfEventType = CursorUtil.getColumnIndexOrThrow(_cursor, "eventType");
        final int _cursorIndexOfTransactionId = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionId");
        final int _cursorIndexOfEnqueueTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "enqueueTimestamp");
        final int _cursorIndexOfAdditionalFields = CursorUtil.getColumnIndexOrThrow(_cursor, "additionalFields");
        final int _cursorIndexOfBody = CursorUtil.getColumnIndexOrThrow(_cursor, "body");
        final List<Event> _result = new ArrayList<Event>(_cursor.getCount());
        while (_cursor.moveToNext()) {
          final Event _item;
          final long _tmpUid;
          _tmpUid = _cursor.getLong(_cursorIndexOfUid);
          final EventType _tmpEventType;
          final String _tmp;
          _tmp = _cursor.getString(_cursorIndexOfEventType);
          _tmpEventType = MindboxRoomConverter.INSTANCE.stringToEventType(_tmp);
          final String _tmpTransactionId;
          _tmpTransactionId = _cursor.getString(_cursorIndexOfTransactionId);
          final long _tmpEnqueueTimestamp;
          _tmpEnqueueTimestamp = _cursor.getLong(_cursorIndexOfEnqueueTimestamp);
          final HashMap<String, String> _tmpAdditionalFields;
          final String _tmp_1;
          if (_cursor.isNull(_cursorIndexOfAdditionalFields)) {
            _tmp_1 = null;
          } else {
            _tmp_1 = _cursor.getString(_cursorIndexOfAdditionalFields);
          }
          if (_tmp_1 == null) {
            _tmpAdditionalFields = null;
          } else {
            _tmpAdditionalFields = MindboxRoomConverter.INSTANCE.stringToHashMap(_tmp_1);
          }
          final String _tmpBody;
          if (_cursor.isNull(_cursorIndexOfBody)) {
            _tmpBody = null;
          } else {
            _tmpBody = _cursor.getString(_cursorIndexOfBody);
          }
          _item = new Event(_tmpUid,_tmpEventType,_tmpTransactionId,_tmpEnqueueTimestamp,_tmpAdditionalFields,_tmpBody);
          _result.add(_item);
        }
        __db.setTransactionSuccessful();
        return _result;
      } finally {
        _cursor.close();
        _statement.release();
      }
    } finally {
      __db.endTransaction();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
